#ifndef __serialConv__
#define __serialConv__

void serialConv(int filterWidth, float *filter, int imageHeight, int imageWidth, float *inputImage, float *outputImage);

#endif